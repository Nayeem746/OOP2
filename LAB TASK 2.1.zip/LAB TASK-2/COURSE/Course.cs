﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COURSE
{
    internal class Course
    {
        private String courseName;
        private String courseCode;
        private int courseCredit;

        public String CourseName
        { get { return courseName; } set { courseName = value; } }
        public String CourseCode
        { get { return courseCode; } set { courseCode = value; } }
        public int CourseCredit
        { get { return courseCredit; } set { courseCredit = value; } }

        public Course() 
         {
        
         }
        public Course(string Cname, string Ccode, int Ccredit)
        {
            courseName = Cname;
            courseCode = Ccode;
            courseCredit = Ccredit;
        }

        public void ShowCourseInfo()
        {
            Console.WriteLine(" CourseName   :" + courseName);
            Console.WriteLine(" CourseCode   :" + courseCode);
            Console.WriteLine(" CourseCredit :" + courseCredit);
        }

        static void Main(string[] args)
        {
            Course course = new Course();
            course.courseName = "OOP 1";
            course.courseCode = "170";
            course.courseCredit = 3;
            course.ShowCourseInfo();

            Console.WriteLine("-----------------------------------------");

            Course course1 = new Course("OOP 2", "180",3) ;
            course1.ShowCourseInfo();

           
        }
    }
}
