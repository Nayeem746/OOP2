﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOUNT
{
    internal class Account
    {
        private String accName;
        private String acid;
        private int balance;

        public String AccName
        { get { return accName; } set {  accName = value; } }
        public String Acid
        { get { return acid; } set {  acid = value; } }
        public int Balance
        { get { return balance; } set {  balance = value; } }


        public Account() { }

        public Account(string accName, string acid, int balance)
        {
            AccName = accName;
            Acid = acid;
            Balance = balance;
        }

        public void Deposit(int amount)
        {
            
                Balance += amount;
                Console.WriteLine("Included Deposit balance :"+Balance);
            
        }

        public void Withdraw(int amount)
        {
            if (amount > 0 && amount <= Balance)
            {
                Balance -= amount;
                Console.WriteLine("New balance after Withdrawn. "+Balance);
            }
            else
            {
                Console.WriteLine(" No enough balance.");
            }
        }

        public void Transfer(int amount, Account receiver)
        { 
            balance -= amount;
            receiver.Balance += balance;
            Console.WriteLine("New balance :" + balance);

        }

        static void Main(string[] args)
        {
            Account account = new Account();
            account.accName = "Nayeem";
            account.acid = "22-46775-1";
            account.balance = 2000;
           
            Console.WriteLine("Account User Name :" + account.accName);
            Console.WriteLine("Account User ID   :" + account.acid);
            Console.WriteLine("Account Balance   :" + account.balance);
            Console.WriteLine("-------------------------------------------------");
            account.Deposit(986);
            account.Withdraw(1000);
            
            Console.WriteLine("-------------------------------------------------------");

            Account account1 = new Account();
            account1.accName = "Rafi";
            account1.acid = "22-46775-1";
            account1.balance = 3000;

            Console.WriteLine("Account User Name :" + account1.accName);
            Console.WriteLine("Account User ID   :" + account1.acid);
            Console.WriteLine("Account Balance   :" + account1.balance);
            Console.WriteLine("-------------------------------------------------");
            account1.Deposit(986);
            account1.Withdraw(1000);
            account1.Transfer(1000, account);

            Console.WriteLine("-------------------------------------------------------");


        }
    }
}
