﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONTACT
{
    internal class Contact
    {
        private String personName;
        private String personId;
        private int age;
        private String mobileNumber;
        private Char gender; 

        public String PersonName
        { get { return personName; } set {  personName = value; } }
        public String PersonId
        { get { return personId; } set { personId = value; } }
        public int Age
        { get { return age; } set {  age = value; } }
        public String MobileNumber
        { get { return mobileNumber; } set {  mobileNumber = value; } }
        public Char Gender
        { get { return gender; } set {  gender = value; } }

        public Contact() { }
        public Contact(string personName, string personId, int age, string mobileNumber, char gender)
        {
            PersonName = personName;
            PersonId = personId;
            Age = age;
            MobileNumber = mobileNumber;
            Gender = gender;
           
        }

        public void ShowPersonInfo()
        {
            Console.WriteLine(" PersonName   :" + personName);
            Console.WriteLine(" PersonId     :" + personId);
            Console.WriteLine(" Age          :" + age);
            Console.WriteLine(" MobileNumber :" + mobileNumber);
            Console.WriteLine(" Gender       :" + gender);

        }

        public void DetectMobileOperator()
        {
            string mobileOperator;

            if (mobileNumber.Length != 11)
            {
                Console.WriteLine("Invalid number.Because here mobile number is more then 11 digit.");
                return;
            }
          
            if (mobileNumber.StartsWith("017") || mobileNumber.StartsWith("013"))
            {
                mobileOperator = "Grameenphone (GP)";
                Console.WriteLine("Mobile Operator: " + mobileOperator);
            }
            else if (mobileNumber.StartsWith("016") || mobileNumber.StartsWith("018"))
            {
                mobileOperator = "Robi";
                Console.WriteLine("Mobile Operator: " + mobileOperator);
            }
            else if (mobileNumber.StartsWith("019") || mobileNumber.StartsWith("014"))
            {
                mobileOperator = "Banglalink";
                Console.WriteLine("Mobile Operator: " + mobileOperator);
            }
            else if (mobileNumber.StartsWith("015") )
            {
                mobileOperator = "Teletalk";
                Console.WriteLine("Mobile Operator: " + mobileOperator);
            }
            else
            {
                Console.WriteLine("Invalid number");
            }


        }



        static void Main(string[] args)
        {
            Contact p1 = new Contact();
            p1.personName = "Nayeem";
            p1.personId = "22-46775-1";
            p1.age = 10;
            p1.mobileNumber = "01817642871";
            p1.gender = 'M';
            p1.ShowPersonInfo();
            p1.DetectMobileOperator();

            Console.WriteLine("----------------------------------------");
            
            Contact p2 = new Contact("Rafi","22-46775-1",20,"015123456789",'F');
            p2.ShowPersonInfo();
            p2.DetectMobileOperator();
        }
    }
}
