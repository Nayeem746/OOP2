﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONSTANT//It can't bd altered and must be initialize.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.1416;
            Console.Write("Enter Radius : ");
            double radius = Convert.ToDouble(Console.ReadLine());
            double area = pi * radius * radius;
            Console.WriteLine("Area is  : " + area);
            Console.ReadLine();
        }
    }
}
