﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaysConversion
{
    internal class Program
    {
         static void Main(string[] args)
        {
            int Years, Months, Weeks, Days;

            Console.Write("ENTER THE DAYES :");
            int T_Days=Convert.ToInt32(Console.ReadLine());

            Years = T_Days / 365;
            Months = ((T_Days%365) / 30);
            Weeks=(((T_Days%365) % 30)/7);
            Days = ((((T_Days % 365) % 30) % 7) % 7);

            Console.WriteLine("YEARS  :"+Years);
            Console.WriteLine("MONTHS :"+Months);
            Console.WriteLine("WEEKS  :"+Weeks);
            Console.WriteLine("DAYS   :"+Days);
        }
    }
}
