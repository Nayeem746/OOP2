﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grad_Calculation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the marks :");
            int marks=Convert.ToInt32(Console.ReadLine());
            if (marks > 100)
            {
                Console.WriteLine("Invelid number");
            }
            else if (marks <= 100 && marks >= 90)
            {
                Console.WriteLine("A+");
            }
            else if (marks < 90 && marks >= 85)
            {
                Console.WriteLine("A");
            }
            else if (marks < 85 && marks >= 80)
            {
                Console.WriteLine("B+");
            }
            else if (marks < 80 && marks >= 75)
            {
                Console.WriteLine("B");
            }
            else if (marks < 75 && marks >= 70)
            {
                Console.WriteLine("C+");
            }
            else if (marks < 70 && marks >= 65)
            {
                Console.WriteLine("C");
            }
            else if (marks < 65 && marks >= 60)
            {
                Console.WriteLine("D+");
            }
            else if (marks < 60 && marks >= 50)
            {
                Console.WriteLine("D");
            }
            else if (marks < 50 && marks >= 0)
            {
                Console.WriteLine("FAIL");
            }
            else if (marks < 0)
            {
                Console.WriteLine("INVELID NUMBER");
            }


            Console.WriteLine("================================");
            Main(args);
        }
    }
}
