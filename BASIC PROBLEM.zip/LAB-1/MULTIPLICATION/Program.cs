﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MULTIPLICATION
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("ENTER THE MULTIPLICATION NUMBER :");
            int num=Convert.ToInt32(Console.ReadLine());
                               
                        
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i+"*"+num+"="+i*num);                     

            }



        }
    }
}
