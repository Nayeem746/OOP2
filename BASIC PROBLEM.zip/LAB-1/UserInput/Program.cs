﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserInput
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("YOUR NAME  :");
            String name=Console.ReadLine();
            Console.Write("UNIVERCITY :");
            String uni = Console.ReadLine();
            Console.Write("ID         :");
            String id=Console.ReadLine();
            Console.Write("PROGRAM    :");
            String prog=Console.ReadLine();
            Console.Write("SEMESTER   :");
            String sem=Console.ReadLine();
            Console.Write("COURSE     :");
            String cou=Console.ReadLine();
            Console.Write("SECTION    :");
            String sec=Console.ReadLine();
            Console.Write("FACULTY    :");
            String fac=Console.ReadLine();
            Console.Write("ROOM(TH)   :");
            String room1=Console.ReadLine();
            Console.Write("ROOM(LAB)  :");
            String room2=Console.ReadLine();
            Console.Write("ROLL       :");
            int roll = Convert.ToInt16(Console.ReadLine());
            Console.Write("CGPA       :");
            double cgpa=Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("==================================");
            Console.WriteLine("NAME       :"+ name);
            Console.WriteLine("UNIVERCITY :"+ uni);
            Console.WriteLine("ID         :"+ id);
            Console.WriteLine("PROGRAM    :"+ prog);
            Console.WriteLine("SEMESTER   :"+ sem);
            Console.WriteLine("COURSE     :"+ cou);
            Console.WriteLine("SECTION    :"+ sec);
            Console.WriteLine("FACULTY    :"+ fac);
            Console.WriteLine("ROOM(TH)   :"+ room1);
            Console.WriteLine("ROOM(LAB)  :"+ room2);
            Console.WriteLine("ROLL       :"+ roll);
            Console.WriteLine("CGPA       :"+ cgpa);
            Console.WriteLine("==================================");


        }
    }
}
