﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LEAP_YEAR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("ENTER THE YEAR :");
            int year= Convert.ToInt16(Console.ReadLine());

            if ((year%4==0)&&(year%100!=0) || (year%400==0))
            {
                Console.WriteLine(year+" IS LEAP YEAR ");            
            }
            else
            {
                Console.WriteLine(year+" IS NOT LEAP YEAR ");
            }
        }
    }
}
