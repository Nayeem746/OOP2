﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductPrice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double PPrice, Weight, TPrice, Taxes, IncludeTaxPrice;
            Console.Write("POTATOS PRICE   :");
             PPrice = Convert.ToDouble(Console.ReadLine());

            Console.Write("POTATOES WEIGHT :");
            Weight=Convert.ToDouble(Console.ReadLine());

            TPrice= (PPrice*Weight);
            Taxes = (((double)5/100)*TPrice);
            IncludeTaxPrice =TPrice+Taxes;

            Console.WriteLine("========================================================");
            Console.WriteLine("TOTAL POTATOS PRICE INCLUDE TAX IS :{0}",IncludeTaxPrice);
            Console.WriteLine("========================================================");
        }
    }
}
