﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int angle1, angle2, angle3, Triangle;
            Console.Write("Enter the 1st Angle :");
            angle1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the 2nd Angle :");
            angle2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the 3rd Angle :");
            angle3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("<==========================================>");

            Triangle = angle1 + angle2 + angle3;
            if (Triangle == 180)
            {
                Console.WriteLine("It is a Triangle");
            }
            else
            {
                Console.WriteLine("It is not a Triangle");
            }


        }
    }
}
