﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CALCULATOR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double number1, number2;
            char operation;

            Console.WriteLine("           NORMAL CALCULATOR");
            Console.WriteLine("=========================================");


            Console.Write("Enter the 1st number :");
            number1=Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the operation  :");
            operation=Convert.ToChar(Console.ReadLine());

            Console.Write("Enter the 2nd number :");
            number2=Convert.ToDouble(Console.ReadLine());

            switch (operation) 
            {
                case '+':Console.WriteLine("RESULT : "+(number1 + number2)); break;
                case '-':Console.WriteLine("RESULT : {1}",number1 - number2); break;
                case '*':Console.WriteLine("RESULT : {2}",number1 * number2); break;
                case '/':Console.WriteLine("RESULT : {3}",number1 / number2); break;
                case '%':Console.WriteLine("RESULT : {4}",number1 % number2); break;
            }

            Main(args);
        }
    }
}
