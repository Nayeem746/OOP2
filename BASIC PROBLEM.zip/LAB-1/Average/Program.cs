﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write 5 integer value ");
            Console.WriteLine("`````````````````````````````````````");
            int sum = 0, n;
            for (int i = 1; i <=5; i++)
            {
                Console.Write("Enter the "+i+" number =");
               n=Convert.ToInt32(Console.ReadLine());
                sum=sum+n;
            }
            Console.WriteLine("=====================================");
            Console.WriteLine("AVERAGE VALUE IS :"+((float)sum/5));
            Console.WriteLine("=====================================");
           
        }

       
    }
}
