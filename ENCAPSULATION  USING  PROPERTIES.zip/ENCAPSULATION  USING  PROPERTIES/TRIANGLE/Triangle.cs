﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRIANGLE
{
    internal class Triangle
    {

        private int x;
        private int y;
        private int z;

        public int X { get { return x; } set { x = value; } }
        public int Y { get { return y; } set { y = value; } }
        public int Z { get { return z; } set { z = value; } }


        public void ShowInfo()
        {
            Console.WriteLine(("X :") + X);
            Console.WriteLine(("Y :") + Y);
            Console.WriteLine(("Z :") + Z);

        }

        public void TestTriangle()
        {
            Console.WriteLine("Testing Triangle ");
            Console.WriteLine("--------------------------------");
            if (X == Y && Y == Z)
            {
                Console.WriteLine("Equilateral  (3 equal sides)");
            }
            else if (X == Y || Y == Z || X == Z)
            {
                Console.WriteLine("Isosceles (2 equal sides)");
            }
            else
            {
                Console.WriteLine("scalene (no equal sides)");
            }


        }

        static void Main(string[] args)
        {
            Triangle triangle = new Triangle();
            triangle.X = 60;
            triangle.Y = 60;
            triangle.Z = 50;
            triangle.ShowInfo();
            triangle.TestTriangle();



            Console.WriteLine();

        }
    }
}
