﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COURSE
{
    internal class Course
    {
        private String courseName;
        private String courseCode;
        private int courseCredit;

        public String CourseName
        { get { return courseName; } set { courseName = value; } }
        public String CourseCode
        { get { return courseCode; } set { courseCode = value; } }
        public int CourseCredit
        { get { return courseCredit; } set { courseCredit = value; } }

        public void ShowCourseInfo()
        {
            Console.WriteLine("Course Name   :" + CourseName);
            Console.WriteLine("Course code   :" + CourseCode);
            Console.WriteLine("Course Credit :" + CourseCredit);
        }

        static void Main(string[] args)
        {
            Course course = new Course();
            course.CourseName = "OOP2";
            course.CourseCode = "1002";
            course.CourseCredit = 3;

            Console.WriteLine("Course Name   :" + course.CourseName);
            Console.WriteLine("Course code   :" + course.CourseCode);
            Console.WriteLine("Course Credit :" + course.CourseCredit);
            Console.WriteLine("--------------------------------------------------");
            course.ShowCourseInfo();

        }
    }
}
