﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ACCOUNT
{
    internal class Account
    {
        private String ac_name;
        private String ac_id;
        private int balance;

        public String Ac_name
        { get { return ac_name; } set { ac_name = value; } }
        public String Ac_id
        { get { return ac_id; } set { ac_id = value; } }
        public int Balance
        { get { return balance; } set { balance = value; } }

        public void Deposits(int amount)
        {
            balance += amount;
            Console.WriteLine("Total balance when Deposits: " + balance);
        }

        public void Withdraw(int amount)
        {

            balance -= amount;
            Console.WriteLine("Total balance when Withdraw:" + balance);
        }

        static void Main(string[] args)
        {
            Account account = new Account();
            account.Ac_name = "NAYEEM";
            account.Ac_id = "16504563788845";
            account.Balance = 2000;

            Console.WriteLine("ACCOUNT NAME    :" + account.Ac_name);
            Console.WriteLine("ACCOUNT ID      :" + account.Ac_id);
            Console.WriteLine("ACCOUNT BALANCE :" + account.Balance);
            Console.WriteLine("-------------------------------------------------");
            account.Deposits(54560);
            account.Withdraw(500);
            Console.WriteLine("-------------------------------------------------");


        }
    }
}
