﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUDENT
{
    internal class Student
    {
        private String name;
        private String id;
        private String dept;
        private Double cgpa;

        public String Name
        { get { return name; } set { name = value; } }
        public String Id
        { get { return id; } set { id = value; } }
        public String Dept
        { get { return dept; } set { dept = value; } }
        public Double Gpa
        { get { return cgpa; } set { cgpa = value; } }

        public void ShowInfo()
        {
            Console.WriteLine("NAME :" + Name);
            Console.WriteLine("ID :" + id);
            Console.WriteLine("Department: " + Dept);
            Console.WriteLine("CGPA :" + Gpa);
        }

        static void Main(string[] args)
        {
            Student student = new Student();
            student.Name = "NAYEEM";
            student.Id = "22-46775-1";
            student.Dept = "BSc CSE";
            student.Gpa = 3.7;

            Console.WriteLine("NAME : " + student.Name);
            Console.WriteLine("ID : " + student.id);
            Console.WriteLine("Department :" + student.Dept);
            Console.WriteLine("CGPA :" + student.Gpa);
            Console.WriteLine("-------------------------------------");
            student.ShowInfo();
            Console.ReadLine();
        }
    }
}
